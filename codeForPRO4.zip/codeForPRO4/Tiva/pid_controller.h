/*
 * pid_controller.h
 *
 *  Created on: 7. maj 2024
 *      Author: aksel
 */

#ifndef PID_CONTROLLER_H_
#define PID_CONTROLLER_H_

void do_pid_control(void *pvParameters);


#endif /* PID_CONTROLLER_H_ */
